import UIKit
/*:
# Playground - Actividad 6
* Operadores personalizados
* Subscripts
* Control de errores

*/


/*: 
### Operadores personalizados
A) Crear el operador para realizar la potencia de el valor "a" a la potencia "b" en valores enteros
*/
prefix operator +++
prefix func +++(valor:Int)->Int{
    let v = 2
    var x = v
    
    let a = valor
    var total = a
    repeat
    {
        total = total*a
        x = (x - 1)
    } while (x > 1)
        return total
    }
   +++6



//: B) Crear el operador |> para ordenar la colección [2,5,3,4] de menor a mayor

var numeros = [2,5,3,4]
numeros.sort()
print(numeros)

/*:
### Subscripts
A) Del conjunto de datos en el Array [2,3,4,5], crear el subscript para modificar los valores multiplicados por el valor 2 y extraer al valor dado un índice.
*/
let array = [2,3,4,5]
class multiplicaciones
{
    var resultado:[Int]
    init(res:[Int]) {
        self.resultado = res
    }
    subscript(idx:Int)->Int
    {
        get{
            return resultado [idx]
        }
        set(newres)
        {
            resultado [idx] = newres * 2
        }
    }
    
}
let multi = multiplicaciones (res:array)
multi[2] = multi[2]
multi.resultado
print("",multi[2])

//: B) Crear el Struct para definir u obtener la posición  para los personaje de tipo Enemigo donde cada posición es de tipo CGPoint aplicnado subscritps
class IYAttachPoint {

  var point:CGPoint?
  var holder: String = "No holder"
  var unavailable: Bool = false
}

/*:
### Control de Errores
A) Crear la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de un colección ["A":1, "B":2,"C":3]
*/
let prueba = ["A":1,"B":2,"C":3]
func ExisteValor(idx:String)
{
    guard prueba[idx] != nil
    else{
        print("No existe")
        return
    }
    print("Si existe")
}
ExisteValor(idx: "C")
prueba["C"]







