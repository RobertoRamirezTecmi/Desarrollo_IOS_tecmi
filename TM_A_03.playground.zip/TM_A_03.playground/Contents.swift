import UIKit
/*:
# Playground - Actividad 3
* Tipos de datos
* Asociación de tipos
* Arreglos y Diccionarios
*/


/*: 
### Actividad de Tipos de datos
A) Declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a una numero entero, un numero decimal (flotante), una cadena de texto, realizando la asignación explicita y la asignación inferida
*/
//entero
var año,edad,dia: Int
año = 2021
edad = 21
dia = 17

//decimal
var segundo,pi,dinero :Double
segundo = 3.5
pi = 3.1416
dinero = 156.50

//cadena de texto
var name,dialetra,mes :String
name = "Roberto"
dialetra = "Miercoles"
mes = "Febrero"

//asignacion explicita e inferida

var x = String()
var y:String = String()

/*:
### Asociación de tipos
A) Declara el tipo de dato por asociación para un tipo de dato String
*/
x = "prueba 1"
y = "prueba 2"
//: B) Declara el tipo de dato por asociación para un tipo de dato  Número entero.
edad = 21


/*: 
### Arreglos y Diccionarios
A) Crea la variable "numeros" de tipo Array con números consecutivos del 1 a 10.
*/
var numero : Array = [1,2,3,4,5,6,7,8,9,10]
//: B) Crea la variable "diasSemana" de tipo Dictionary con la relación numero:día Ej. 1:"Lunes"
var diasSemana : Dictionary<Int,String> = [1:"Lunes",2:"Martes",3:"Miercoles",4:"Jueves",5:"Viernes",6:"Sabado",7:"Domingo"]

/*:
### Condicionales y Ciclos
A) Declarar la variable "datos" con los valores [3,6,9,2,4,1]
*/
var datos = [3,6,9,2,4,1]
//: B) realizar el recorrido de la variable "datos" con la instrucción "for"
for i in datos {
    print(i)
}

//: C) Encontrar los valores menores a 5
print("Los valores menores a 5 son:")
for i in datos {
    if i < 5 {
        print(i)
    }
    
}




