import UIKit
/*:
# Playground - Actividad 5
* Class y Struct
* Extension
* Optional
*/


/*: 
### Actividad Class y Struct
A) Diseñar la clase Persona que contenga dos metodos, el primero "Saludar" que reciba el parámetro nombre y regrese el mensaje el nombre mas el texto "mucho gusto", el segundo metodo "Caminar" que reciba como parámetro un tipo de dato Int y regrese un tipo de dato String indicando el numero de pasos caminados.
*/
class persona{
    var saludar = "default"
    var caminar = 0;
    func nombre()->String{
        return("Hola,mucho gusto \(saludar)")
    }
    func camina()->String{
        return("Beto camino \(caminar) pasos")
    }
    
}
var lapersona = persona()
lapersona.saludar = "beto"
lapersona.caminar = 20
lapersona.nombre()
lapersona.camina()
//: B) Diseñar el struct "Pantalla" la cual recibirá como como parametros el ancho y alto de una pantalla como tipo de datos Int con un constructor, para inicializar la estructura.
struct pantalla {
    var ancho:Int
    var alto:Int
}

/*:
### Extensions
A) Diseñar un extensión del tipo de dato Int que represente las horas y que pueda regresar los segundos correspondientes (puedes utilizar una función o una variable computada)
*/
extension Int{
    var horas:Int{
        return self*1
    }
    var segundo:Int{
        return self*1440
    }
}
let hora = 24.horas
let segundo = 60.segundo
print("Un dia equivale a \(hora) horas")
print("24 horas equivalen a \(segundo) segundos")

//: B) Diseñar una extensión del tipo de dato String que represente un día de la semana y regrese el numero correspondiente iniciando con Domingo = 1 y finalizando Sábado = 7
extension String{
    var Domingo:String{return "Domingo es el 1 dia"}
    var Lunes:String{return "Lunes es el 2 dia"}
    var Martes:String{return "Martes es el 3"}
    var Miercoles:String{return "Miercoles es el 4 dia"}
    var Jueves:String{return "Jueves es el 5 dia "}
    var Viernes:String{return "Viernes es el 6 dia"}
    var Sabado:String{return "Sabado es el 7 dia"}
}
let dia1 = "".Domingo
let dia2 = "".Lunes
let dia3 = "".Martes
let dia4 = "".Miercoles
let dia5 = "".Jueves
let dia6 = "".Viernes
let dia7 = "".Sabado
print("\(dia4)")
/*:
### Optionals
A) Diseñar una variable optional para recibir el tipo de dato Int en caso de que exista.
*/
let numeros = ["1":1,"2":2,"3":3]
var numero:Int?

numero = numeros ["1"]

if numeros["1"] != nil{
    print("Existe")
}else{
    print("No existe")
}


//: B) Para la colección let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200] diseñar una variable opcional para recibir el valor de dias["DF"]
let dias = ["GDL":120,"PUE":300,"MTY":100,"CDMX":200]
var dia:Int?
if dias["DF"] != nil{
print("Si existe")
}else{
    print("No existe")
}




